public class SingleInistilition {
    public static void main(String[] args) {
        int []a={33,21,34,12};
        for(int i=0;i<=a.length-1;i++){
            System.out.println(a[i]);
        }
    }
}
