public class ArrayRavers {
    public static void main(String[] args) {
        int a[]=new int[]{1,2,3,4,5,6,7};
        for(int i=a.length; i>0;i--){
            System.out.println(i);
        }
    }
}
