package Array;

public class finbdestacetwopoint {
    public static void main(String[] args) {


        int x1 = 2, y1 = 3, x2 = 4, y2 = 3;

        double d =Math.sqrt(Math.pow(x2 - x1 ,2)+Math.pow(y2  - y1 , 2));
        System.out.println(d);

    }
}
