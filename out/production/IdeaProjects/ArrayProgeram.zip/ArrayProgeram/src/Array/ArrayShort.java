package Array;

import java.util.Arrays;

public class ArrayShort {
    public static void main(String[] args) {
        int arr[]={1,2,5,4,6,3};
        Arrays.sort(arr);
        System.out.println(Arrays.toString(arr));
    }
}
