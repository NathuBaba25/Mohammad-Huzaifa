public class ArrayForeachloop {
    public static void main(String[] args) {
        int arr[]={10,21,40,31,15};
        for(int i:arr){
            System.out.println(i);
        }
    }
}
