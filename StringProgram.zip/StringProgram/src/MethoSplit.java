package StringProgram.src;

public  class MethoSplit  {
    public static void main(String[] args) {
         int  a=144;
        System.out.println(Math.sqrt(a));


    }
}
