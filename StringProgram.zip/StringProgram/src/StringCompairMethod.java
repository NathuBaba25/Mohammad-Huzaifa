package StringProgram.src;
public class StringCompairMethod {
    public static void main(String[] args) {
        String s="Huzaifa";
        String s1="Hozaifa";
        String s2="Huzaifa";
        System.out.println(s.compareTo(s1));
        System.out.println(s1.compareTo(s2));
        System.out.println(s.compareTo(s2));

    }
}
