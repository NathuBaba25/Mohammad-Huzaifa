package StringProgram.src;

public class StrprogermLogic {
    public static void main(String[] args) {
        String x="xyz";
        x.toUpperCase();
        String y=x.replace("y","Y");
        System.out.println(y);
        y =y+"abc";
        System.out.println(y);

    }
}
