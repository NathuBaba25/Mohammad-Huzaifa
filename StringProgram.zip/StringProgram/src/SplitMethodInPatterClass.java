package StringProgram.src;

import java.util.regex.Pattern;

public class SplitMethodInPatterClass {
    public static void main(String[] args) {
        Pattern p=Pattern.compile("\\s");
        String [] s=p.split("Subhanallah alhumdulillah Allahuakbar");
        for(String s2  :  s) {
            System.out.println(s2);
        }
    }
}
