package StringProgram.src;

import java.util.*;
public class Tkenizer {
    public static void main(String[] args) {
        StringTokenizer st=new StringTokenizer("Huzaifa khan From Balipur");
        StringTokenizer s=new StringTokenizer("Khan mohammad huzaifa");
        while (st.hasMoreTokens()){
            System.out.println(st.nextToken());
            System.out.println(s.nextToken());
        }
    }
}
