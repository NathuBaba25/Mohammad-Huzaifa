package StringProgram.src;

public class IntToString {
    public static void main(String[] args) {
        int i=100;
        String s=String.valueOf(i);
        System.out.println(i+100);
        System.out.println(s+10);
        int s3=10;
        String s2=Integer.toString(s3);
        System.out.println(s2+5);
        System.out.println(s3+4);

    }
}
